import { InMemoryPrestamoRepository } from '../infra/in-memory-prestamo.repository.js';
import { PrestamoService } from '../servicios/prestamo.service.js';
import { EjemplarPrestadoError } from '../errores/ejemplar-prestado.error.js';

async function testCaminoFeliz(): Promise<void> {
  const repositorio = new InMemoryPrestamoRepository();
  const servicio = new PrestamoService(repositorio);

  const prestamo = await servicio.crear({
    libroId: 'LIB-0001',
    socioId: 'S-100',
    ejemplares: [1, 2],
  });

  if (prestamo.estado === 'activo' && prestamo.ejemplares.length === 2) {
    console.log('PASS: camino feliz - se creo el prestamo correctamente');
  } else {
    console.log('FAIL: camino feliz - el prestamo no quedo como se esperaba');
  }
}

async function testEjemplarDuplicado(): Promise<void> {
  const repositorio = new InMemoryPrestamoRepository();
  const servicio = new PrestamoService(repositorio);

  await servicio.crear({
    libroId: 'LIB-0002',
    socioId: 'S-200',
    ejemplares: [5],
  });

  try {
    await servicio.crear({
      libroId: 'LIB-0002',
      socioId: 'S-201',
      ejemplares: [5],
    });
    console.log('FAIL: ejemplar duplicado - debio lanzar un error y no lo hizo');
  } catch (e) {
    if (e instanceof EjemplarPrestadoError) {
      console.log('PASS: ejemplar duplicado - se lanzo el error correcto');
    } else {
      console.log('FAIL: ejemplar duplicado - lanzo un error distinto al esperado');
    }
  }
}

async function main(): Promise<void> {
  await testCaminoFeliz();
  await testEjemplarDuplicado();
}

main(); 